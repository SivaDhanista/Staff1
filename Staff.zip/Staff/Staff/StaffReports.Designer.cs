﻿namespace Staff
{
    partial class StaffReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.cbdes = new System.Windows.Forms.ComboBox();
            this.txtmail = new System.Windows.Forms.TextBox();
            this.txtadd = new System.Windows.Forms.TextBox();
            this.cbgen = new System.Windows.Forms.ComboBox();
            this.dtdob = new System.Windows.Forms.DateTimePicker();
            this.txtcon = new System.Windows.Forms.TextBox();
            this.StaffDGV = new System.Windows.Forms.DataGridView();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnbtm = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.StaffDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(94, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(94, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Designation";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(97, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(97, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Address";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(331, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(27, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Dob";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(331, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Gender";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(331, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Contact";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(174, 37);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(121, 20);
            this.txtname.TabIndex = 7;
            // 
            // cbdes
            // 
            this.cbdes.FormattingEnabled = true;
            this.cbdes.Items.AddRange(new object[] {
            "Associate Enginner",
            "Test Engineer",
            "Software Developer"});
            this.cbdes.Location = new System.Drawing.Point(174, 84);
            this.cbdes.Name = "cbdes";
            this.cbdes.Size = new System.Drawing.Size(121, 21);
            this.cbdes.TabIndex = 8;
            // 
            // txtmail
            // 
            this.txtmail.Location = new System.Drawing.Point(174, 127);
            this.txtmail.Name = "txtmail";
            this.txtmail.Size = new System.Drawing.Size(121, 20);
            this.txtmail.TabIndex = 9;
            // 
            // txtadd
            // 
            this.txtadd.Location = new System.Drawing.Point(174, 181);
            this.txtadd.Multiline = true;
            this.txtadd.Name = "txtadd";
            this.txtadd.Size = new System.Drawing.Size(432, 42);
            this.txtadd.TabIndex = 10;
            // 
            // cbgen
            // 
            this.cbgen.FormattingEnabled = true;
            this.cbgen.Items.AddRange(new object[] {
            "MALE",
            "FEMALE"});
            this.cbgen.Location = new System.Drawing.Point(406, 92);
            this.cbgen.Name = "cbgen";
            this.cbgen.Size = new System.Drawing.Size(200, 21);
            this.cbgen.TabIndex = 11;
            // 
            // dtdob
            // 
            this.dtdob.Location = new System.Drawing.Point(406, 41);
            this.dtdob.Name = "dtdob";
            this.dtdob.Size = new System.Drawing.Size(200, 20);
            this.dtdob.TabIndex = 12;
            // 
            // txtcon
            // 
            this.txtcon.Location = new System.Drawing.Point(406, 134);
            this.txtcon.Name = "txtcon";
            this.txtcon.Size = new System.Drawing.Size(200, 20);
            this.txtcon.TabIndex = 13;
            // 
            // StaffDGV
            // 
            this.StaffDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.StaffDGV.Location = new System.Drawing.Point(100, 289);
            this.StaffDGV.Name = "StaffDGV";
            this.StaffDGV.Size = new System.Drawing.Size(551, 124);
            this.StaffDGV.TabIndex = 14;
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(116, 240);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(75, 23);
            this.btnadd.TabIndex = 15;
            this.btnadd.Text = "ADD";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click_1);
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(232, 240);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 23);
            this.btnupdate.TabIndex = 16;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click_1);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(353, 240);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(75, 23);
            this.btndelete.TabIndex = 17;
            this.btndelete.Text = "DELETE";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click_1);
            // 
            // btnbtm
            // 
            this.btnbtm.Location = new System.Drawing.Point(459, 240);
            this.btnbtm.Name = "btnbtm";
            this.btnbtm.Size = new System.Drawing.Size(98, 23);
            this.btnbtm.TabIndex = 18;
            this.btnbtm.Text = "BACKTOMAIN";
            this.btnbtm.UseVisualStyleBackColor = true;
            this.btnbtm.Click += new System.EventHandler(this.btnbtm_Click_1);
            // 
            // StaffReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnbtm);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.StaffDGV);
            this.Controls.Add(this.txtcon);
            this.Controls.Add(this.dtdob);
            this.Controls.Add(this.cbgen);
            this.Controls.Add(this.txtadd);
            this.Controls.Add(this.txtmail);
            this.Controls.Add(this.cbdes);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "StaffReports";
            this.Text = "StaffReports";
            this.Load += new System.EventHandler(this.StaffReports_Load);
            ((System.ComponentModel.ISupportInitialize)(this.StaffDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.ComboBox cbdes;
        private System.Windows.Forms.TextBox txtmail;
        private System.Windows.Forms.TextBox txtadd;
        private System.Windows.Forms.ComboBox cbgen;
        private System.Windows.Forms.DateTimePicker dtdob;
        private System.Windows.Forms.TextBox txtcon;
        private System.Windows.Forms.DataGridView StaffDGV;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnbtm;
    }
}