﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Staff
{
    public partial class BenfitsManagement : Form
    {
        SqlConnection conn;
        public BenfitsManagement()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }
  
        private void BenfitsManagement_Load(object sender, EventArgs e)
        {
            display();
           
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string query;
            query = string.Format("update Benefits set EmployeeID='{0}',BenfitName='{1}',Description='{2}'",  txtempid.Text  , txtstatus.Text, txtdes.Text);          
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record updated");
                conn.Close();
                display();
                
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void benefits_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            if(txtempid.Text=="" || txtstatus.Text=="" || txtdes.Text=="")
            {
                MessageBox.Show  ("Missing Information");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "insert into Benefits values( " + txtempid.Text + ", '" + txtstatus.Text + "','" + txtdes.Text +"' )";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Benfits Sucessfully added");
                   

                    conn.Close();
                    display();

                }
                catch(Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (txtempid.Text == "")
            {
                MessageBox.Show("enter the employee id");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "delete from Benefits where EmployeeID='" + txtempid.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Benfits deleted Sucessfully");
                    conn.Close();
                    display();

                }
                catch(Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }

            }
        }
        private void display()
        {
          conn.Open();
          string query = "select * from Benefits";
          SqlDataAdapter sd = new SqlDataAdapter(query, conn);
          SqlCommandBuilder builder = new SqlCommandBuilder(sd);
          var ds = new DataSet();
          sd.Fill(ds);
          benefits.DataSource = ds.Tables[0];
          conn.Close();
        }  

        
    }
}
