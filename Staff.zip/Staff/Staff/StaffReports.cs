﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Staff
{
    public partial class StaffReports : Form
    {
        SqlConnection conn;
        public StaffReports()
        {

            InitializeComponent();


            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }


        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        private void populate()
        {

            conn.Open();

            string query = "select * from STAFF_REPORTS";
            SqlDataAdapter sda = new SqlDataAdapter(query, conn);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            StaffDGV.DataSource = ds.Tables[0];
            conn.Close();
        }


        private void StaffReports_Load(object sender, EventArgs e)
        {
            populate();
        }



        /* private void StaffDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
         {


             txtname.Text = StaffDGV.SelectedRows[0].Cells[0].Value.ToString();
             cbdes.Text = StaffDGV.SelectedRows[0].Cells[1].Value.ToString();

             txtmail.Text = StaffDGV.SelectedRows[0].Cells[2].Value.ToString();
             dtdob.Text = StaffDGV.SelectedRows[0].Cells[3].Value.ToString();
             cbgen.Text = StaffDGV.SelectedRows[0].Cells[4].Value.ToString();
             txtcon.Text = StaffDGV.SelectedRows[0].Cells[5].Value.ToString();
             txtadd.Text = StaffDGV.SelectedRows[0].Cells[6].Value.ToString();



         }*/



        private void btnbtm_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dashboard obj = new Dashboard();
            obj.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnadd_Click_1(object sender, EventArgs e)
        {
            if (txtname.Text == "" || cbdes.Text == "" || txtmail.Text == "" || txtadd.Text == "" || dtdob.Text == "" || cbgen.Text == "" || txtcon.Text == "")
            {
                MessageBox.Show("Missing Info");
            }

            else
            {
                try
                {

                    conn.Open();
                    string query = "insert into STAFF_REPORTS values('" + txtname.Text + "','" + cbdes.Text + "','" + txtmail.Text + "','" + dtdob.Text + "','" + cbgen.Text + "','" + txtcon.Text + "','" + txtadd.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("inserted");
                    conn.Close();
                    populate();




                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);


                }
            }
        }

        private void btnupdate_Click_1(object sender, EventArgs e)
        {
            /* if (txtname.Text == "" || cbdes.Text == "" || txtmail.Text == "" || txtadd.Text == "" || dtdob.Text == "" || cbgen.Text == "" || txtcon.Text == "")
             {

                 MessageBox.Show("missing info");
             }*/
            // else
            //{

            try
            {
                conn.Open();
                // string query = "update STAFF_REPORTS set name='" + txtname.Text + "',des='" + cbdes.Text + "',mail='" + txtmail.Text + "',add='" + txtadd.Text + "',dob='" + dtdob.Text + "',gen='" + cbgen.Text + "',contact='" + txtcon.Text + "' where name='"+txtname.Text+"',";
                SqlCommand cmd = new SqlCommand("update STAFF_REPORTS set Name='" + txtname.Text + "',DESIGNATION='" + cbdes.Text + "',EMAIL='" + txtmail.Text + "',ADDRESS='" + txtadd.Text + "',DOB='" + dtdob.Text + "',GENDER='" + cbgen.Text + "',CONTACT='" + txtcon.Text + "' where NAME='" + txtname.Text + "'", conn);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Staff UPDATED Successfully");
                conn.Close();
                populate();

            }
            catch (Exception Ex)
            {

                MessageBox.Show(Ex.Message);
            }
        }

        private void btndelete_Click_1(object sender, EventArgs e)
        {
            if (txtname.Text == "")
            {

                MessageBox.Show("Enter the Name Of Staff");

            }
            else
            {

                try
                {
                    conn.Open();
                    string query = "delete from STAFF_REPORTS where name='" + txtname.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, conn);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Staff deleted Successfully");
                    conn.Close();
                    populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);

                }
            }
        }

        private void btnbtm_Click_1(object sender, EventArgs e)
        {

        }
    }
}
        
    

